Grailbird.data.tweets_2013_11 = 
[ {
  "source" : "test system",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406054311244746752",
  "text" : "This is a test tweet in a test archieve file",
  "id" : 406054311244746752,
  "created_at" : "2013-11-28 13:37:46 +0000",
  "user" : {
    "name" : "Glenn Jones",
    "screen_name" : "glennjones",
    "protected" : false,
    "id_str" : "946491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1442481406\/Glenn_Jones_normal.png",
    "id" : 946491,
    "verified" : false
  }
}, ]