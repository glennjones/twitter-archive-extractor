var user_details =  {
  "expanded_url" : "http:\/\/glennjones.net\/",
  "screen_name" : "glennjones",
  "location" : "Brighton, UK",
  "url" : "http:\/\/t.co\/VEMJTCiEH7",
  "full_name" : "Glenn Jones",
  "bio" : "Exploring semantic mark-up and data portability ideas. Founder of Madgex. Brighton geek",
  "id" : "946491",
  "created_at" : "2007-03-11 19:15:57 +0000",
  "display_url" : "glennjones.net"
}